<?php

return [
    'name'=>'نام'
    ];