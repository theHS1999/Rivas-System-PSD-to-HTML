Click here to reset your password: {{ url('pass/reset/'.$token) }}
