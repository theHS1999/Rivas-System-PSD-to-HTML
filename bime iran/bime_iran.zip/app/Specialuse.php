<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Specialuse extends Model
{
    protected $fillable=['name'];
}
