<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contractservice extends Model
{
    protected $fillable = ['contract_id','contractCommit_id','service_id'];
}
