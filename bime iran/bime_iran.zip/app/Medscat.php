<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Medscat extends Model
{
    protected $fillable= ['expertise_id','med_id'];
}
