<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Specialmed extends Model
{
    protected $fillable=['use_id','med_id'];
}
